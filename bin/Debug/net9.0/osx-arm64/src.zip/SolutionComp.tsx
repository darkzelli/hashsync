function SolutionComp({ step, values }: {step: number, values: number[]}){
    return(
        <div className="flex flex-col items-center justify-center text-white gap-y-4 ">Step: {step}<div className="flex gap-4">
          <div className="flex items-center justify-center border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[0]}</div>
          <div className="flex items-center justify-center border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[1]}</div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[2]}</div>
          <div className=' h-12 w-1 bg-white'></div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[3]}</div>
        </div>
        <div className="flex gap-4 ">
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[4]}</div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[5]}</div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[6]}</div>
          <div className='h-12 w-1 bg-white'></div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[7]}</div>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[8]}</div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[9]}</div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[10]}</div>
          <div className='h-12 w-1 bg-white'></div>
          <div className="flex items-center justify-center  border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md">{values[11]}</div>
        </div></div>
    );
}
export default SolutionComp;