import { ReactNode, useEffect, useState } from 'react'

import './App.css'
import SolutionComp from './SolutionComp'

function App() {
  const [val1, setVal1] = useState<number>()
  const [val2, setVal2] = useState<number>()
  const [val3, setVal3] = useState<number>()
  const [val4, setVal4] = useState<number>()
  const [val5, setVal5] = useState<number>()
  const [val6, setVal6] = useState<number>()
  const [val7, setVal7] = useState<number>()
  const [val8, setVal8] = useState<number>()
  const [val9, setVal9] = useState<number>()
  const [val10, setVal10] = useState<number>()
  const [val11, setVal11] = useState<number>()
  const [val12, setVal12] = useState<number>()
  const [solutions, setSolutions] = useState<number[][] | null>([])
  
  function swap(head: number[], swap: number[]): number[][]{
    return([swap, head])
    
  }
  function calculateRows(): number[][]{
    const row1: number[] = []
    const row2: number[] = []
    const row3: number[] = []
    if(val1) row1.push(val1)
    if(val2) row1.push(val2)
    if(val3) row1.push(val3)
    if(val4) row1.push(val4)

    if(val5) row2.push(val5)
    if(val6) row2.push(val6)
    if(val7) row2.push(val7)
    if(val8) row2.push(val8)

    if(val9) row3.push(val9)
    if(val10) row3.push(val10)
    if(val11) row3.push(val11)
    if(val12) row3.push(val12)
    

    return ([row1, row2, row3])
  }
  function runCalculate(){
    const [row1, row2, row3] = calculateRows()
    

  }
  return (
    <div className='flex flex-col items-center justify-center min-h-screen bg-black gap-y-25'>
      <div className='flex flex-row items-center justify-center gap-8'>
        <div className='flex flex-col items-center justify-center gap-y-4'><div className="flex gap-4">
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal1(Number(e.target.value))}/>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal2(Number(e.target.value))}/>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal3(Number(e.target.value))}/>
          <div className='h-12 w-1 bg-white'></div>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal4(Number(e.target.value))}/>
        </div>
        <div className="flex gap-4 ">
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal5(Number(e.target.value))}/>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal6(Number(e.target.value))}/>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal7(Number(e.target.value))}/>
          <div className='h-12 w-1 bg-white'></div>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal8(Number(e.target.value))}/>
        </div>
        <div className="flex gap-4">
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal9(Number(e.target.value))}/>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal10(Number(e.target.value))}/>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal11(Number(e.target.value))}/>
          <div className='h-12 w-1 bg-white'></div>
          <input className="border-2 border-white w-10 h-12 text-center text-lg bg-transparent text-white rounded-md" type='number' onChange={(e) => setVal12(Number(e.target.value))}/>
        </div></div>
        <div>
          <button className='bg-white w-15 h-10 rounded-md cursor-pointer' onClick={() => runCalculate()}>Enter</button>
        </div>
      </div>
      <div className="w-full no-scrollbar overflow-x-scroll flex flex-row items-center justify-center gap-25">
        {
          solutions?.map((row, rowIndex) => (
            <SolutionComp key={rowIndex} values={row} step={rowIndex}/>
          ))
        }
      </div>
    </div>
  )
}

export default App
