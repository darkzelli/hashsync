TBD is the book of all the known knowledge on desire. It contains four chapters. Currently held safely and securely by the kingdom. 
1. General Knowledge of Desires and how they work.
2. Classifying and grouping desires
3. Every known desire and their rank given by the traveler
4. The travelers research on How to make the desires you want (This chapter is lost)


note - desires can be created in many ways one way
1. desire is created to get out of a life threanting situation
2. Overwelming desire to do something
3. Obsession over something. ex. be able to control carbon
#### Chapter 1 - General Knowledge
##### What are desires? 

##### Conditions 

#### [[Chapter 2 - Classifying]]
##### Traveler's Mark

#### [[Chapter 3 - Desires]]



