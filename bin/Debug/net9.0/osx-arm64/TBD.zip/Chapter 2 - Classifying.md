#### Traveler's Mark

	The traveler's mark is a ranking system i designed to classify and rank all desires. The system is pretty simply. Desires are given two values ranging from 1 to 9. The first number represents the base level of effectiveness/power of the desire compared to similar desire. The second number represents the base level of effectiveness/power of the desire compared to all known desires. Effectiveness meaning how well it achieves its goal compared to other desires. 

For example: 

	A desire with a TM(Traveler's Mark) of 4|3 means the desire is power/effectiveness of achieving its intended goal/use compared to similar desires is a 4, with 1 being the least effective and 9 being the most effect. The 3 represnts the desirees power/effectiveness of achieving its intended goal/use compared to all desires is a 3. Overall meaning it is a releatively weak desire. 

Note: 

	The system is designed in a way to measure and classify the base level of a desire. This does not take into account how the desire is used by its user. Meaning the desire could be more or less powerful then its TM. 
