All known import or known desires

#### Will of the undead

	Ability : aiblity to respawn
	Activation: 
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 7|9
#### One's Truth

	Ability : tell if someone is lying or not
	Activation: 
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 8|5

#### Desireless

	Ability : temporarly remove the desires of any peron
	Activation: placing a hand on a target
	Conditions: while the hand is on the target they will not be able to use their desire
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 8|8

#### Pathless

	Ability : Anything that has a direct path towards its user will choose a new path that doesn't lead to contact between said thing and the user.
	Activation: 
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 7|7

#### Hidden Eye

	Ability : allows the user to place one eye anywhere in the world by hand. Which will allow the user to see through that eye.
	Activation: 
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 6|7

#### Blessed

	Ability : Give anyone who wants a desire, a desire that the user has access to. - Duplicates the desire allowing both people to have it. 
	Activation: 
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 8|8

#### Stand in

	Ability : to create an exact verion of the user, like a copy.
	Activation: 
	Conditions: The user and the stand in are unable to make contact or see each other.  
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 5|7

#### Peer

	Ability: able to see through, pass through and pass anything through any surface
	Activation:
	Conditions: limited range, surfaces can not be in motion, the user can not breath while passing through surfaces
	Benefits:
	Side-Effects:  
	Signature User: Akumetsu Kurogami
	Traveler's Mark: 5|8

#### Heart's Truth

	Ability: force someone to tell the truth
	Activation:
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: Shin Clan
	Traveler's Mark: 9|6

#### My Subjects

	Ability: control someone's mind
	Activation:
	Conditions: 
	Benefits:
	Side-Effects:  
	Signature User: 
	Traveler's Mark: 9|8
