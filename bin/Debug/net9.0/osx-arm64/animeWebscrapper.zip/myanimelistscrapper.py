import requests
from bs4 import BeautifulSoup
from fpdf import FPDF
from os.path import basename


amount = 200
URL = "https://myanimelist.net/topanime.php?limit={}".format(amount)
page = requests.get(URL)  
soup = BeautifulSoup(page.content, "html.parser") 
results = soup.find_all("tr", class_="ranking-list")
arr = []
for item in results:
    title = item.find("h3", class_="hoverinfo_trigger fl-l fs14 fw-b anime_ranking_h3").text
    cover = item.find("a", class_="hoverinfo_trigger fl-l ml12 mr8")
    image = cover.find("img", class_="lazyload")
    src = image['data-srcset']
    src2 = src.split(",", 1)[1]
    src3 = src2.split(" 2x", 1)[0]
    with open(basename(src3), "wb") as f:
        f.write(requests.get(src3).content)
    fully_all = "{{title: \"{}\", cover: \"{}\" }},".format(title,src3)
    arr.append(fully_all)
text_list = ""
for item in arr:
    text_list = text_list + item
fully_formatted = "[" + text_list + "]"
print(len(arr))
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size = 12)
pdf.multi_cell(200, 10, txt = fully_formatted , align = 'L')
pdf.output(dest="F", name="fefe.pdf")

