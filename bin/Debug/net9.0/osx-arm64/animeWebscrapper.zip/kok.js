const http = new XMLHttpRequest();
const url = "https://realpython.github.io/fake-jobs";
http.open("GET", url);
http.send()

http.onreadystatechange = (e) =>{
    console.log(http.responseText)
}

console.log(http.responseText)