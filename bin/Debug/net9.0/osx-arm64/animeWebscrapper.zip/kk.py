import requests
from bs4 import BeautifulSoup

url = "https://realpython.github.io/fake-jobs/"
idk = requests.get(url)
print(idk.content)