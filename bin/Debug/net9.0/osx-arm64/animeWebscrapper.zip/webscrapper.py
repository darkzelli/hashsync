
import requests
from bs4 import BeautifulSoup
from fpdf import FPDF

URL = "https://realpython.github.io/fake-jobs/"
page = requests.get(URL)


soup = BeautifulSoup(page.content, "html.parser")
results = soup.find(id="ResultsContainer")
job_elements = results.find_all("div", class_="card-content")
arr = []
for job_element in job_elements:
    print(job_element, end="\n"*2)
for job_element in job_elements:
    title_element = job_element.find("h2", class_="title")
    company_element = job_element.find("h3", class_="company")
    location_element = job_element.find("p", class_="location")

    format_title = title_element.text.strip()
    format_company = company_element.text.strip()
    format_location = location_element.text.strip()
    formattedAll = "{{title: {}, company: {}, location: {} }},".format(format_title, format_company, format_location)
    arr.append(formattedAll)
text_list = ""
for item in arr:
    text_list = text_list + item
fullyformatted = "[" + text_list + "]"

pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size = 12)
pdf.multi_cell(200, 10, txt = fullyformatted , align = 'L')
pdf.output(dest="F", name="data.pdf")




###
    fully_all = "{{title: \"{}\", cover: \"{}\" }},".format(title,src3)
    arr.append(fully_all)
text_list = ""
for item in arr:
    text_list = text_list + item
fully_formatted = "[" + text_list + "]"
print(len(arr))
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size = 12)
pdf.multi_cell(200, 10, txt = fully_formatted , align = 'L')
pdf.output(dest="F", name="fefe.pdf")
###