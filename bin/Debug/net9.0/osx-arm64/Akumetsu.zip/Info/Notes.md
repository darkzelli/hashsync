Main Villain - Akumetsu Kurogami"

At somepoint right before akumetsu is about to switch to a new body he challenges the leader of all the forces (King or whatever) to solo combat and just proves that he can when without killing him. Then akumetsu dies losing his # life moving onto the next. 


Name of the Manga - Akumetsu, named after the main villian who is infact not a villian but the main charcter, the story follows the a different person, but the sole purpose of the story is to show that what Akumetsu believes in is the right belief. 

idea - Picture of all the deadmen taking a pictures without there skulls on smiling with their robes and dirty gear on. some smiling some not. 

Akumetsu puts Akiro in a situation where he can either save the majority of people (the world) or his brother Akashi. He ends up choosing akashi

And akumetsu says "see you are no hero. you would choose your own brother over the world."

"I would choose the world over anyone. Even myself if It came down to it."

It is ok thoug, because you have fulfilled your role Akiro. You have proven to me and to the world that emotions are only a weakness. 

Are you getting it now? you're the villain not me. See you've killed millions all for the sake of your brother. But me I sacrificed 7. 

Yes, In all the lives i have lived I have only killed 7. We have only killed 7. Your friends that you think are dead are not. They will be Reborn when the times comes. 






right before Akumetsu is about to die. "I guess they will always see me as the villain."