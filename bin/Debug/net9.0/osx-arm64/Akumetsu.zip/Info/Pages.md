Ch 1:
page 1: 

	"What was that?"

	Akiro hears screaming and starts to run. 

	In the distance he sees a post/pole.

	He can see a silouette of a man hanging from a pole. 

	As he approaches he hears coughing and wonders who the man is

	As he gets closer he realizes that this is no man but a mere child like himself and the coughing, was the child throwing up blood. 

	As the blood falls to the ground akiro continues to approach

	"I'll get you help don't worr-"

	Akiro is finally able to make out who it is. It is his brother. 

	Akiro falls to knees as he looks up to the lifeless body of his brother. 

	A fallen angel or god.

	The drops of blood become the only thing he can hear, the rest of the world is silent. 

	flash foward ends.
	


page 2: 

	cdcdc



Page 4:



	Akashi is in a field a little bit away from his house. He is using his ability to transform carbon into different weapons and tools.



page 5: 

	A deadmen underling and Akumetsu's second body (not known) are on their way to kill Akumetsu's first body on the orders of one of the captains. 
	
	The underling is newer to the organization and asks Akumetsu Questions

	"How are we supposed to kill this guy?"

	Akumetsu does not say a word and keeps walking without acknowleding the underling

	"Oh yeah right? thats a dumb question."

	"Do we know who were killing?"

	"No"

	"You're really willing to kill without knowing why or who you're killing"

	"Yes"

	"You know when I joined this organization. They said you would have to be able to put your own emotions and ideas to side to achieve its goal.

	"But you are emotionless... "

	Akumetsu turns to face the underling

	"Do you believe emotions are a hinderance? or that they're needed?"

	Underling is suprised "Huh?"

	"Let me think"
	
	  "I think emotions are what make us humans. They make life worth living. Without them there would be no happiness or sadness. No love or hate. Life would cease to exist. Without emotions we would only be thriving. Emotions are what allow us to truly live. And being able to live is what makes us special"

	"Interesting" Akumetsu turns and continues to walk

	"thats him. Look before we do this. Know that depite what I said back there. I will not hesitate to complete my mission."

	Akumetsu smirks