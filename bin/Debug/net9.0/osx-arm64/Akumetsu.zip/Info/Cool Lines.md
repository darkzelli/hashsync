"A monster is what they made me"
"not even death can hold me"
"Everytime i come back the lines between who i am and who i pretend to be blurr"
