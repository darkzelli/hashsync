

"Are you guys all good. Are you gonna go to sleep?"

"I think we need a bedtime story" 

"Yeah we do"

"No not tonight, I think you should get your rest. "

"PLEASE, Dad"

"Ok, ok, a quick one."

"Are we choosing the favorite again? "

"can you tell us your one of your stories"

"Yeah, a scary one"

"Mhmmm ok, Let me think?"

"I have just story"

"In the beginning there were 12 warring tribes, each tribe believed they were the strongest" 

"Tired of the never ending wars, the 12 tribe leaders came together, and decided to host an all or nothing death match" With the winning tribe earning the write to rule and govern the other 11. 

"Each tribe was to select a representative, a man or women who embodied their values and strength. "






"As the last two remaining combatants fought the crowds cheered"

"Hoping that their tribe would be victorious, but it was obvious who was going to win"

"One warrior was far stronger than the other"

"As the tribal seals of his fallen combatants hung from his waist he laughed"

"uttering the words "

"Your actions are futile, the only thing ahead of you is pain. You have served your purpose die knowing you have at least achieved that"

"The warrior dashed behind is fragile and frozen opponent" 

"Whisking his sword between the chest of his final enemy"

"His enemy, unable to react could only hope and pray that he would live"

"He didn't want to die, he didn't even want to fight in this battle."

"He was only chosen because of his elderly tribe he was the only youth, capable of competing"

"With his desire to live, it is said as the sword pierced his heart. He was granted the ability to be reborn"

"Years after the summit concluded and the victory claimed his rightful thrown, A new tribe was born"

"I say tribe lightly, most consider them a clan. A clan of deadmen"

"Deadmen?"

"Men, that have given up on everything making them human"

"It is believed that the leader of this 13th clan, is that hopeless boy who just wanted to live"

"No longer, a boy but a man who despises our gracious leaders, our traditions, and everything we stand for."

"THE END"

"is he really still alive?"

"No, no i'm sure he is dead."

"Well, does the 13th clan really exist?"

"They sound cool"

"No, I'm sure that is also just folklore"

"Folklore?"

"a rumor"

"Anyways, time for you guys to sleep"

"aaaaa, One more PLEASE"

"If you don't the 13th clan will get you"
