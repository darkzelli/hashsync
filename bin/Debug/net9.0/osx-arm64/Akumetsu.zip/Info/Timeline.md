(parenthesis) = unknown to viewer
1. The twin brother of the main character is killed and hung from a pole ( Killed by a member of deadmen, because he believed that he was the second vessel/life of Akumetsu <span style="color:#c00000">to prevent a loophole that means Akumetsu can not show his face (face of his second life) to any of the deadmen. Otherwise the person intended to kill his second life would not make the mistake of killing someone he believed to be him because he would know his face</span>.
2. The main character's desire is born from the event of his brother dying. His desire, to have made it in time to save his brother gives him the desire of being able to reverse time. 
3. The main character tells his parents and they get the body. Later on they have a funeral ceremony for his brother and they lay him to rest.
4. The main character vows to find the person who killed his twin brother and kill him. He vows to get strong so he can protect his family. 
5. The main character is known to visit his brother grave on many occasions. He usually visits his grave at night. On night after drinking or taking drugs he visits which he got from one of his friends. While he is walking away he hears something in the distance towards the direction of his brothers grave. He turns and sees a silhouette of a figure. He watches as the man punches through the ground and into the grave of his brother.  He continues to watch as the man stands there without moving. As the man pulls his arm out, he yells to scare him away. The man turns and but unable to make out a face because of the distance, drugs, or because of the man was wearing someone over his face. He believed that the man was a skeleton with no skin. As he starts to run closer the man disappears (<span style="color:#c00000">The man is akumetsu and he uses the ability stand in, then relinquishes it making his stand in disappear. Note that to avoid a loophole Akumetsu has to receive the ability stand in from his second life )</span>
6.    After learning of the mistake that his deadmen made he realizes that he need to do it himself. So he goes to the house of his second life preparing to kill him. The second says "It's my time isn't akumetsu", "Sadly it is. but i will bear your pain as my own and your will, will become mine. (After killing his second life, akumetsu receive his ability which is stand-in)
7.  Akumetsu cleaning up the mess of his fellow deadmen he goes out to bless the dead twin with the desire blessed. <span style="color:#c00000">For loophole purposes blessed has to be his hereditary desire. Doing this will revive the twin in the same way Akumetsu was revived. </span> Because he is giving him the desire will of the undead. Which is why he was at the grave site. <span style="color:#c00000">(He uses his stand-in to do this while his real body returns to his base.)</span>
















1. Akumetsu wants to prove that he is not a villain, and a hero is usually the villain. He also questions whether or not he is in the right. He wants to answer one question "Are emotions only a hinderance. " If he is wrong he will admit that he is wrong and that emotions are useful and lay down his arms. But he believes he is right. Emotions are useless
2. Akumetsu orders one of his captains to kill his previous bodies. He specifically gives it to captain that he knows lays off work to his underlings. This is his goal. He gives the name to the captain who then gives it to the underlying. But akumetsu gave the wrong name. He gave the name of Akashi. - Akumetsu goes on the mission with the underling the underling doesn't recognize him because everyone except his trusted advisor doesn't know his face.-, - The names of all his bodies and captains are secret only known to Akumetsu and his most trusted advisor - 
3. Akashi is then killed and hung up on a pole so that his brother Akiro finds him. Akumetsu wants Akiro to find him hoping that as a big brother he will want to avenge his little brother. 
4. He calculates the probability and outcome of the desire that will be created from this tragedy.
5. He dwindles down the number of possible desires and then proceeds to figure out how he can acquire desires that will combat and defeat these desires.  
