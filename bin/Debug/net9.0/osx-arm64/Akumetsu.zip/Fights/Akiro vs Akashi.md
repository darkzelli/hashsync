Akiro finishes fighting Rajin killing him because he believed that he killed his brother. 


Plunges sword in rajin killing him while rajin is smiling. Akiro huffs"I thought that would feel better"

"Have you not gain satisfaction in avenging me"

Akiro turns around and stares into the darkness as a silhouette approaches from it.

"Hey brother, it's been while. How are you?"

"Akashi is that you? No "

------------------------------

"Brother, I have avenged you"

"Foolish, brother I am alive and well"

"Akashi? No you can't be" - As the shadow of a person closers walks closer to Akiro

"Yes Akiro, I'm here"

"No you are not my brother, he's dead. Even if you were you look nothing like him"

"You don't trust your younger brother?"
"I see you haven't changed. You know I've always wondered why you came first. I've been a better big brother then you've ever been" 
"I mean i did inherit the family desire. While you were desireless I was powerful."
"Or so I thought, now i have real power"

"If you really are Akashi why would you join these terrorists.  The real Akashi would never" 

"The real akashi? haha. You are right previous me would despise these people. But that akashi you knew is dead. He died when his worthless big brother was to slow to save him"
"its alright thought I don't need saving anymore"

"You know alot about akashi but you were clearly never him. Now i'll give you a choice flee or die"

"You still don't believe me huh. " - Akashi appears being akiro and whispers in his ear. What he whispers is currently unknown to the audience but he says Akiro hidden nickname that only akashi had for him. 

Akiro eyes widen and he jumps backwards. "Akashi" in a soft tone

"It's really you akashi?"

"Yes, brother. Its me"

"Akashi, why would you join this organization"

"I've already told you brother. It's because of you. But it's ok brother because I have real power now" "I can save us both. Join me"

"No, akashi come home with me. i'm sure dad and mom would want to see you"

"You want me to give up everything, i've ever wanted for you. "

"No for our family, for yourself. You need us and we need you"

"I am doing this for myself and this is my family now. You can either join or die."

"Akashi Please"

"Seems like you have chosen" 

"Brother, Please"

"You are no brother of mine, Brother to my last life. Which has officially ended."
"Blood no longer binds us. Mere memories. Memories that are forgotten just as easily as they were created."
"Now my the memory your death live with me forever"


Akashi forms a graphene spear from his ability and chucks it Akiro, as the spear barrels toward akiro. Akashi dashes behind forming another knife as he swings. As he swings he utters the words “looks like you’ve gotten slow brother” Akiro noticing both the spear and his brother teleports away. Which surprises akashi. Akiro says “Im faster then you’ll ever be” with a spear still heading towards akashi he dodges it letting it pass most of his body before the back of it and hurling at the new position of Akiro. Akiro teleports again but this time behind his brother. As the spear leaves his hand akiro kicks his back foot causing him to fall foward as he falls akiro grabs his face and throws him backwards straight toward the ground. As akiro stand above akiro he says “give up brother you have lost”.
