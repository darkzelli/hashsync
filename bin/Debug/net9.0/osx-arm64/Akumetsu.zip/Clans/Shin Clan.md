also known as the truth clan. 

Hereditary Desire: 