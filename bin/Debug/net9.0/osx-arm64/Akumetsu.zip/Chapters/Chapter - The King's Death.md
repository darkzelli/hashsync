How did you get in? 

I'm surprised you noticed. Then again. You were always observant. 

You don't know me. You may think you do. Just like the rest of my followers. 
It's alright though. All followers are welcome. Would you like a blessing or something. 
