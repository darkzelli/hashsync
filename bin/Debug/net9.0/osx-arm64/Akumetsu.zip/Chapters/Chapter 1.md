Our main character can be seen crying on his knees in front of a pole. Hanging from the pole is his twin baby brother

-MC-
Brother. What have you done to deserve this?

[Screams, slowly calling out quietly]
Goooooood. God. God. 

God. Why? 

No, there is no such thing. I speak only to myself. 

Believe me brother i will find who did this to you. And Avenge you. 

-
Continues crying
Flashback ends

>end

