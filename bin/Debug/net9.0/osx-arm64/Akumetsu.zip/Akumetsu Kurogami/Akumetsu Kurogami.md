

<span style="color:#00b0f0"> Main Desire</span> - Will of the undead

<span style="color:#c00000"><span style="color:#4a967f">Ability</span></span> - to respawn

<span style="color:#4a967f">Hereditary Desire</span> - Blessed

**<span style="color:#7d6868"><span style="color:#4a967f">Activation</span></span>**: Upon death

**<span style="color:#c00000"><span style="color:#4a967f">Conditions</span></span>**: His previous body has to be killed within 2 days after his new body is claimed

**<span style="color:#4a967f">Benefits</span>**: He is able to keep the desire he gains from each body he claims - Only after that body is killed

<span style="color:#c00000">Side Effects</span>: 

		1. Loses the ability to use a body part after being reborn - ex. Blindness - only one at a time, unless its his eyes. 
		2. Unable to stay within his new body longer than his original body and he has less time in his new body every time - ex. original body 22 years old, second body able to stay inside for 15 years, then next body, 10 years, then 5, then 3, then 2 , 1 or something like that

<span style="color:#4a967f">Organization</span>: Deadmen

<span style="color:#4a967f">All Desires</span>: 
[[Chapter 3 - Desires#Will of the undead]]

[[Chapter 3 - Desires#One's Truth]]

[[Chapter 3 - Desires#Desireless]]

[[Chapter 3 - Desires#Pathless]]

[[Chapter 3 - Desires#Hidden Eye]]

[[Chapter 3 - Desires#Blessed]]

[[Chapter 3 - Desires#Stand in]]

[[Chapter 3 - Desires#Peer]]

<span style="color:#4a967f">Clan/Tribe</span>:  4th clan - Kurogami

<span style="color:#4a967f">Desire Event</span>: 

<span style="color:#4a967f">Villain Motivation</span>: 
1. He is mad that is parents who had him at a late age making them elderly weren't able to give him the life that he wanted. They were never able to play with him. and he was forced to fight for his clan and save them because they were unable to fight. He wanted to feel protected but he was always protecting them. (After he is reborn he goes back to them planning on killing them to make them feel the pain he felt. Does he kill them or does he let them live)
2. He didn't want to die he just wanted live. 

<span style="color:#4a967f">Goal</span>: 

<span style="color:#4a967f">Role</span>: Main Villain

<span style="color:#c00000">Bodies</span>:

		1. OG - Akumetsu Kurogami - Will of the undead
		2. -
		3. -
		4. -
		5. -
		6. -
		7. 